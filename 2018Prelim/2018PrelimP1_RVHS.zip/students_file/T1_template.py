###########TASK 1.1###########
def readfile():
    pass

###########TASK 1.2###########
def count_class(clss):
    pass

print("Task 1.2 - Evidence 3")
for clss in ["warrior", "mage", "priest"]:
    print("Number of " + clss + ":" + str(count_class(clss)))
print()

###########TASK 1.3###########
def top_class_by_season(season):
    pass

print("Task 1.3 - Evidence 5")
for i in range(1, 13):
    print("Top class in season " + str(i) + ":")
    print(top_class_by_season(i))
    
###########TASK 1.4###########
def top_n_players_by_season(topn, season):
    pass

print("Task 1.4 - Evidence 7")
print(top_n_players_by_season(20, 9))
###########TASK 1.5###########
def find_stagnant_players():
    pass

print("Task 1.5 - Evidence 9")
print(find_stagnant_players())
