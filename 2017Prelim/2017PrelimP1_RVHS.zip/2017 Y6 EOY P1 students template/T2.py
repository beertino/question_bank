import random

#Task 2.1
def is_valid_ISBN10(isbn10):
    pass

print(is_valid_ISBN10("0306406152")) #True
print(is_valid_ISBN10("0306406153")) #False
print(is_valid_ISBN10("030640615X")) #False
print(is_valid_ISBN10("9971502100")) #True
print(is_valid_ISBN10("8175257660")) #True

#Task 2.2
def possible_ISBN(isbn):
    pass

print(possible_ISBN("9971222???"))#singapore
print()
print(possible_ISBN("9971??23?X"))#singapore
print()
print(possible_ISBN("8175?5?9?6"))#Japan
print()

#Task 2.3
def menu():
    pass

#menu()
